const mongoose = require("mongoose");
const schema = mongoose.Schema;

const studentSchema = new schema({
    name: { type: String, required: true, index: true },
    department: { type: String, required: true },
    courses: { type: [String], required: true },
    degree: { type: Number, required: true },
    age: { type: Number, required: true },
});

// optional compound index example
studentSchema.index({ name: 1, department: 1 });

const Student = mongoose.model("Student", studentSchema);

module.exports = Student;
