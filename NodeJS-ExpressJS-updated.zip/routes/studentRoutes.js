const express = require('express');
const router = express.Router();
const studentCtrl = require('../controllers/studentController');
const { isAuthenticated } = require('../utils/authMiddleware');

// عرض كل الطلاب - محمي (يمكن تغييره حسب الرغبة)
router.get('/', isAuthenticated, studentCtrl.getAllStudents);

// عرض صفحة إضافة طالب جديد
router.get('/new', isAuthenticated, studentCtrl.showAddForm);

// إضافة طالب جديد
router.post('/', isAuthenticated, studentCtrl.createStudent);

// البحث عن الطلاب
router.get('/search', isAuthenticated, studentCtrl.searchStudents);

// عرض صفحة تعديل طالب
router.get('/edit/:id', isAuthenticated, studentCtrl.showEditForm);

// تعديل بيانات الطالب
router.post('/edit/:id', isAuthenticated, studentCtrl.updateStudent);

// حذف طالب
router.post('/delete/:id', isAuthenticated, studentCtrl.deleteStudent);

// عرض تفاصيل طالب معين
router.get('/:id', isAuthenticated, studentCtrl.getStudentById);

module.exports = router;
