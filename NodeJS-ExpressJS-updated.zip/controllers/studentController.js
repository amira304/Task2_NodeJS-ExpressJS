const Student = require('../models/MyDataSchema');

// عرض كل الطلاب
exports.getAllStudents = async (req, res) => {
  try {
    const students = await Student.find().sort({ name: 1 });
    res.render('students', { myTitle: 'All Students', students, user: req.session.user });
  } catch (err) {
    res.status(500).send('Error fetching students');
  }
};

// عرض صفحة الإضافة
exports.showAddForm = (req, res) => {
  res.render('index');
};

// إضافة طالب جديد
exports.createStudent = async (req, res) => {
  try {
    const coursesArray = req.body.courses
      .split(',')
      .map(c => c.trim())
      .filter(c => c);

    const newStudent = new Student({
      name: req.body.name,
      department: req.body.department,
      courses: coursesArray,
      degree: req.body.degree,
      age: req.body.age,
    });

    await newStudent.save();
    res.redirect('/students');
  } catch (error) {
    console.error(error);
    res.status(400).send({ message: 'Error creating student', error });
  }
};

// عرض تفاصيل طالب واحد
exports.getStudentById = async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if(!student) return res.status(404).send('Student not found');
    res.render('studentDetails', { student, user: req.session.user });
  } catch (err) {
    res.status(404).send('Student not found');
  }
};

// عرض صفحة التعديل
exports.showEditForm = async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if(!student) return res.status(404).send('Student not found');
    res.render('editStudent', { student });
  } catch (err) {
    res.status(404).send('Student not found');
  }
};

// تعديل بيانات الطالب
exports.updateStudent = async (req, res) => {
  try {
    const coursesArray = req.body.courses
      .split(',')
      .map(c => c.trim())
      .filter(c => c);

    await Student.findByIdAndUpdate(req.params.id, {
      name: req.body.name,
      department: req.body.department,
      courses: coursesArray,
      degree: req.body.degree,
      age: req.body.age,
    });
    res.redirect('/students');
  } catch (err) {
    res.status(400).send('Error updating student');
  }
};

// حذف الطالب
exports.deleteStudent = async (req, res) => {
  try {
    await Student.findByIdAndDelete(req.params.id);
    res.redirect('/students');
  } catch (err) {
    res.status(400).send('Error deleting student');
  }
};

// البحث عن الطلاب
exports.searchStudents = async (req, res) => {
  try {
    const q = req.query.q || '';
    const department = req.query.department || '';
    const filter = [];

    if(q) {
      filter.push({
        $or: [
          { name: new RegExp(q, 'i') },
          { department: new RegExp(q, 'i') }
        ]
      });
    }

    if(department) {
      filter.push({ department });
    }

    const queryObj = filter.length ? { $and: filter } : {};
    const students = await Student.find(queryObj).limit(100);
    res.render('students', { myTitle: 'Search Results', students, user: req.session.user });
  } catch (err) {
    res.status(500).send('Error searching students');
  }
};
